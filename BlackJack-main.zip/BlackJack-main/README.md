# BlackJack
A Black Jack game project for university purposes.


Coding in C# and JS
